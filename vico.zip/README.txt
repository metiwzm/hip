## Needs!
Go https://my.telegram.org/auth?to=apps and register a application 
save Api_id and Api_hash and copy to config.ini


>installation 
chmod +x installer.sh
./installer
>after install
>enter number ...
>close server and open again 
>Finally:
screen python3.6 bot.py

error :>
python3.6 -m pip reinstall pyrogram


__| BotHelps
for commands help Send `help` in your pv or others

--
https://t.me/WebinoSource
